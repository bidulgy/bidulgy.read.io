const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const scoreEl=document.getElementById('score'),comboEl=document.getElementById('combo'),judgeEl=document.getElementById('judge');
const overlay=document.getElementById('start'),startBtn=document.getElementById('startBtn');
const W=canvas.width,H=canvas.height,SOUL={x:450,y:548};
const TRAVEL=1250,WINDOW=145;
let chart=[],audio=new Audio('assets/sans.mp3'),playing=false,score=0,combo=0,last=0,particles=[],flash=0;
let judgeTimer=0;

fetch('chart.json').then(r=>r.json()).then(c=>chart=c);

startBtn.onclick=async()=>{await startGame()};
async function startGame(){
 overlay.style.display='none'; score=0;combo=0;particles=[];flash=0;
 audio.currentTime=0; audio.volume=.8; await audio.play();
 playing=true; last=performance.now(); requestAnimationFrame(loop);
 setJudge('START');
}
function restart(){if(playing){audio.currentTime=0;score=0;combo=0;particles=[];flash=0;setJudge('RESTART')}else startGame()}
function setJudge(t){judgeEl.textContent=t;judgeEl.style.opacity=1;clearTimeout(judgeTimer);judgeTimer=setTimeout(()=>judgeEl.style.opacity=.25,420)}
function fmt(n){return String(n).padStart(6,'0')}

addEventListener('keydown',e=>{
 if(e.repeat)return;
 if(e.key.toLowerCase()==='r'){restart();return}
 if(e.key.toLowerCase()==='m'){if(audio.paused)audio.play();else audio.pause();return}
 if(playing)hit();
});
addEventListener('pointerdown',e=>{if(playing && e.target===canvas)hit()});

function hit(){
 const now=audio.currentTime*1000;
 let best=null,bd=Infinity;
 for(const n of chart){
   if(n.hit||n.missed)continue;
   const d=Math.abs(n.time*1000-now);
   if(d<bd){bd=d;best=n}
 }
 if(!best || bd>WINDOW){combo=0;setJudge('MISS');flash=.12;return}
 best.hit=true;
 if(bd<=45){score+=100+combo*2;combo++;setJudge('PERFECT');}
 else if(bd<=90){score+=60;combo++;setJudge('GOOD');}
 else {score+=20;combo=0;setJudge('BAD');}
 burst();flash=.08;
}

function burst(){
 for(let i=0;i<14;i++)particles.push({x:SOUL.x,y:SOUL.y,vx:(Math.random()-.5)*5,vy:(Math.random()-.5)*5,life:1});
}
function drawArena(){
 ctx.fillStyle='#070707';ctx.fillRect(0,0,W,H);
 ctx.strokeStyle='#252525';ctx.lineWidth=3;ctx.strokeRect(90,70,720,500);
 ctx.strokeStyle='#171717';ctx.beginPath();ctx.moveTo(120,500);ctx.lineTo(780,500);ctx.stroke();
 // subtle beat pulse
 const pulse=Math.max(0,1-Math.abs((audio.currentTime*1000%500)-250)/250);
 ctx.globalAlpha=.12*pulse;ctx.fillStyle='#fff';ctx.fillRect(90,70,720,500);ctx.globalAlpha=1;
}
function drawSoul(){
 ctx.save();ctx.translate(SOUL.x,SOUL.y);
 ctx.fillStyle='#ff4052';ctx.beginPath();
 ctx.moveTo(0,18);ctx.lineTo(-18,-1);ctx.lineTo(-18,-10);ctx.lineTo(-10,-17);ctx.lineTo(0,-9);
 ctx.lineTo(10,-17);ctx.lineTo(18,-10);ctx.lineTo(18,-1);ctx.closePath();ctx.fill();
 ctx.restore();
}
function drawProjectile(n,now){
 const hit=n.time*1000,spawn=hit-TRAVEL, t=Math.max(0,Math.min(1,(now-spawn)/TRAVEL));
 const ease=t*t*(3-2*t),x=n.x+(SOUL.x-n.x)*ease,y=n.y+(SOUL.y-n.y)*ease;
 ctx.save();ctx.translate(x,y);
 const ang=Math.atan2(SOUL.y-n.y,SOUL.x-n.x);ctx.rotate(ang);
 ctx.fillStyle=n.type==='orb'?'#e8f2ff':n.type==='arrow'?'#dfff75':'#fff';
 if(n.type==='orb'){ctx.beginPath();ctx.arc(0,0,10,0,Math.PI*2);ctx.fill();ctx.fillStyle='#111';ctx.fillRect(-3,-3,6,6)}
 else if(n.type==='arrow'){ctx.beginPath();ctx.moveTo(16,0);ctx.lineTo(-9,-10);ctx.lineTo(-3,0);ctx.lineTo(-9,10);ctx.closePath();ctx.fill()}
 else if(n.type==='cross'){ctx.fillRect(-4,-15,8,30);ctx.fillRect(-15,-4,30,8)}
 else {ctx.beginPath();ctx.moveTo(0,-14);ctx.lineTo(14,0);ctx.lineTo(0,14);ctx.lineTo(-14,0);ctx.closePath();ctx.fill()}
 ctx.restore();
}
function loop(now){
 if(!playing)return;
 const dt=Math.min(50,now-last);last=now;
 drawArena();
 const t=audio.currentTime*1000;
 for(const n of chart){
   if(n.hit||n.missed)continue;
   if(t>n.time*1000+WINDOW){n.missed=true;combo=0;setJudge('MISS');continue}
   if(t>=n.time*1000-TRAVEL)drawProjectile(n,t);
 }
 for(const p of particles){p.x+=p.vx;p.y+=p.vy;p.life-=dt/700;ctx.globalAlpha=Math.max(0,p.life);ctx.fillStyle='#fff';ctx.fillRect(p.x,p.y,4,4)}
 ctx.globalAlpha=1;drawSoul();
 scoreEl.textContent=fmt(score);comboEl.textContent=combo;
 if(flash>0){ctx.fillStyle='#fff';ctx.globalAlpha=flash;ctx.fillRect(0,0,W,H);ctx.globalAlpha=1;flash-=dt/1000}
 if(audio.ended){playing=false;setJudge('FINISH');overlay.style.display='flex';startBtn.textContent='PLAY AGAIN'}
 requestAnimationFrame(loop);
}
